#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <bits/stdc++.h>
using namespace std;

bool Encrypt(string fld, string userkey);
bool Key_comp(string fld, size_t hash);
int blocker(string a);
int unblocker(string a);

int main ()
{
	cout << "Enter the full independent path to .key" << endl;
	string fld = "";
	cin >> fld;
	
	unblocker(fld);
	ifstream file(fld);
	if (!file.good())
	{
		cout << "Wrong folder for .key!" << endl;
		return 1;
	}
	file.close();
    	cout << "Enter the key to see sysinfo" << endl;
    	string key;
    	cin >> key;
    	if (Encrypt(fld, key))
    	{
    		cout << "Access denied!" << endl;
    		blocker(fld);
		unblocker(".sys.tat");
		ifstream file(".sys.tat");
		if (!file.good())
		{
			cout << "Wrong folder for secure.exe or file doesn't exist!" << endl;
			return 1;
		}
		system("base64 -d .sys.tat");
		file.close()
		blocker(".sys.tat");
   	}
   	else {
		file.close();
		blocker(fld);
    		cout << "Wrong key! Try again later" << endl;
    		}
    	return 0;
}

bool Encrypt(string fld, string userkey)
{
    	string salt = "salt";
    	string str = salt + userkey;
    	hash <string> hasher;
    	size_t hash = hasher(str);
    	return Key_comp(fld, hash);
}

bool Key_comp(string fld, size_t hash)
{
	ifstream file(fld);
	string ekey;
	getline(file,ekey);
	string key = to_string(hash);
	file.close();
	if (key == ekey)
		return 1;
	else 
		return 0;
}

int blocker(string a) {
	char c[100];
	char v[100];
	const char* b3 = "sudo chmod ugo-r ";
	const char* b1 = "sudo chattr +i ";
	const char* b2 = a.c_str();
	strcpy(c, b3);
	strcat(c, b2);

	system(c);
	
	strcpy(v, b1);
	strcat(v, b2);

	system(v);
	return 0;
}

int unblocker(string a) {
	char c[100];
	char v[100];
	const char* b3 = "sudo chmod ugo+r ";
	const char* b1 = "sudo chattr -i ";
	const char* b2 = a.c_str();
	strcpy(v, b1);
	strcat(v, b2);

	system(v);
	
	strcpy(c, b3);
	strcat(c, b2);

	system(c);
	return 0;
}
