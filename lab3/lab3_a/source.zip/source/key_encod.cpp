#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>
#include <bits/stdc++.h>
using namespace std;

int main (int argc, char** argv) 
{
    string salt = "salt";
    string userkey = argv[1];
    string str = salt + userkey;
    hash <string> hasher;
    size_t hash = hasher(str);
    cout << hash;
}
