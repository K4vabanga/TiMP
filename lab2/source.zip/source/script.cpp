#include <iostream>
#include <fstream>
#include <fstream>
#include <string.h>
#include <cstdlib>
#include <cstring>
#include <cmath>

using namespace std;

int checkinst();
void loging(int attempts, int type);
int HashFunc(int k);

int main() {
	string old_n, new_n;
	int tmp = 0;
	int atm;

	cout << "Loading..." << endl;
	atm = checkinst();
	if (atm || atm == -1) {
		ifstream file("names.txt"); //Проверка повтора имен
		cout << "Input username: ";
		cin >> new_n;
		while (getline(file, old_n)) {
			if (old_n.compare(new_n) == 0) {
				cout << "Name has been already passed" << endl;
				tmp = 1;
				break;
			}
		}
		file.close();
		if (!tmp) {
			ofstream os("names.txt", ios::out | ios::app);
			os << new_n << endl;
			cout << "Completed" << endl;
			os.close();
			}
		loging(atm, 0);
	}
	else {
		string des, b="b", B="B", d="d", D="D"; //Выбор варианта покупки или продажи
		int key_t = 242554996, key_b;
		
		cout << "Buy the full version or uninstall the program" << endl;
flg:
		cout << "B/D?" << endl;
		cin >> des;
		if (des.compare(B) == 0 or des.compare(b) == 0) {
			cout << "Enter the key: ";
			cin >> des;
			key_b = atoi(des.c_str());
			if (HashFunc(key_b) == key_t) {
				cout << "Successfully! Restart the program" << endl;
				loging(atm, 1);
			}
			else {
				cout << "Invalid key!" << endl;
				goto flg;
			}
		}
		
		else if (des.compare(D) == 0 or des.compare(d) == 0) {
			system("sudo apt-get remove lab2"); 
			//ofstream os("/var/log/lab.log", ios::out | ios::app); //раскомментировать для установки
			//os << "Uninstall" << endl;
			//os.close();
			//system("sudo rm rm names.txt");
			//system("sudo rm rm script");
	}
			
		else
			goto flg;
	}
	return 0;
}

int checkinst() {
	string atm1, atm2;
	int attempts, tmp1, tmp2, tmp3;
	string b, del = "Uninstall", bou = "Bought";
	fstream logs("/var/log/lab.log");
	if (!logs.good()){
		system("sudo touch /var/log/lab.log");
		cout << "Welcome!" << endl;
		logs.close();
		return 3;
		}
	else {
		while (getline(logs, atm2)) {
			tmp2 ++;
			if (atm2.compare(del) == 0) {
				tmp1 = tmp2;
				continue;
			}
			else if (atm2.compare(bou) == 0) {
				tmp3 = 1;
				continue;
			}
			atm1 = atm2;
		}
		if (tmp1 == tmp2) //Проверка наличия программы до этого
				cout << "The program has been already installed on this computer before" << endl;
		attempts = atoi(atm1.c_str());
		logs.close();
		if (tmp3 == 1) { //Наличие полной версии
			cout << "This is full version! Thank for your purchase" << endl;
			attempts = -1;
		}
		return attempts;
		}
}

void loging(int attempts, int type) { //Логгирование
	if (!type) {
		if (attempts != -1) {
			ofstream os("/var/log/lab.log", ios::out | ios::app);
			attempts -= 1;
			cout << "Remaining trial runs: " << attempts << endl;
			os << attempts << endl;
			os.close();
		}
		else {
			ofstream os("/var/log/lab.log", ios::out | ios::app);
			os << "Bought" << endl;
			os.close();
		}
	}
	else if (type) {
		ofstream os("/var/log/lab.log", ios::out | ios::app);
		os << "Bought" << endl;
		os.close();
	}
}

int HashFunc(int k) {
	int n = 1000000000;
	double a = 0.618033988;
	int h = n * fmod (k * a, 1);
	return h;
}
