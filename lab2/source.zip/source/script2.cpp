#include <iostream>
#include <fstream>
#include <fstream>
#include <string.h>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cmath>

using namespace std;

int checkinst();
void loging(int attempts, int type);
int HashFunc(int k);

int main() {
	string old_n, new_n, exit = ":q";
	int atm;

	cout << "Loading..." << endl;
	atm = checkinst();
	time_t start = time(0); //В целом все тоже самое, но добавили функцию проверки по времени
	if (atm > 0) { //Полная версия
		while(((int) (time(0) - start)) < atm) {
			
			int tmp = 0;
			ifstream file("names.txt");
			cout << "Input username or ':q' for exit: ";
			cin >> new_n;
			if (exit.compare(new_n) == 0) {
				int atm1;
				atm1 = atm - (int) (time(0) - start);
				if (atm1 < 0) 
					atm1 = 0;
				loging(atm1, 0);
				return 0;
			}
			while (getline(file, old_n)) {
				if (old_n.compare(new_n) == 0) {
					cout << "Name has been already passed" << endl;
					tmp = 1;
					break;
				}
			}
			file.close();
			if (!tmp) {
				int atm1;
				ofstream os("names.txt", ios::out | ios::app);
				os << new_n << endl;
				atm1 = atm - (int) (time(0) - start);
				if (atm1 < 0) 
					atm1 = 0;
				loging(atm1, 0);
				cout << "Completed" << endl;
				os.close();
			}
		}
	}
	else if (atm == -1) { //Триал версия
		while (1) { 
			int tmp = 0;
			ifstream file("names.txt");
			cout << "Input username or ':q' for exit: ";
			cin >> new_n;
			if (exit.compare(new_n) == 0) {
				loging(atm, 0);
				return 0;
			}
			while (getline(file, old_n)) {
				if (old_n.compare(new_n) == 0) {
					cout << "Name has been already passed" << endl;
					tmp = 1;
					break;
				}
			}
			file.close();
			if (!tmp) {
				ofstream os("names.txt", ios::out | ios::app);
				os << new_n << endl;
				cout << "Completed" << endl;
				os.close();
			}
		}
	}
	else {
f1:
		string des, b="b", B="B", d="d", D="D";
		int key_t = 242554996, key_b;
		
		cout << "Buy the full version or uninstall the program" << endl;
flg:
		cout << "B/D?" << endl;
		cin >> des;
		if (des.compare(B) == 0 or des.compare(b) == 0) {
			cout << "Enter the key: ";
			cin >> des;
			key_b = atoi(des.c_str());
			if (HashFunc(key_b) == key_t) {
				cout << "Successfully! Restart the program" << endl;
				loging(atm, 1);
				return 0;
			}
			else {
				cout << "Invalid key!" << endl;
				goto flg;
			}
		}
		
		else if (des.compare(D) == 0 or des.compare(d) == 0) {
			system("sudo apt-get remove lab2");
			//ofstream os("/var/log/lab.log", ios::out | ios::app); //раскомментировать для установки
			//os << "Uninstall" << endl;
			//os.close();
			//system("sudo rm rm names.txt");
			//system("sudo rm rm script");
			return 0;
		}
			
		else
			goto flg;
	}
	cout << "Trial time is up" << endl;
	goto f1;
}

int checkinst() {
	string atm1, atm2;
	int attempts, tmp1, tmp2, tmp3;
	string b, del = "Uninstall", bou = "Bought";
	fstream logs("/var/log/lab.log");
	if (!logs.good()){
		system("sudo touch /var/log/lab.log");
		cout << "Welcome!" << endl;
		logs.close();
		return 180;
	}
	else {
		while (getline(logs, atm2)) {
			tmp2 ++;
			if (atm2.compare(del) == 0) {
				tmp1 = tmp2;
				continue;
			}
			else if (atm2.compare(bou) == 0) {
				tmp3 = 1;
				continue;
			}
			atm1 = atm2;
		}
		if (tmp1 == tmp2)
				cout << "The program has been already installed on this computer before" << endl;
		attempts = atoi(atm1.c_str());
		logs.close();
		if (tmp3 == 1) {
			cout << "This is full version! Thank for your purchase" << endl;
			attempts = -1;
		}
		return attempts;
	}
	
}

void loging(int attempts, int type) {
	if (!type) {
		if (attempts != -1) {
			ofstream os("/var/log/lab.log", ios::out | ios::app);
			cout << "Remaining trial sec: " << attempts << endl;
			os << attempts << endl;
			os.close();
		}
		else {
			ofstream os("/var/log/lab.log", ios::out | ios::app);
			os << "Bought" << endl;
			os.close();
		}
	}
	else if (type) {
		ofstream os("/var/log/lab.log", ios::out | ios::app);
		os << "Bought" << endl;
		os.close();
	}
}

int HashFunc(int k) {
	int n = 1000000000;
	double a = 0.618033988;
	int h = n * fmod (k * a, 1);
	return h;
}
